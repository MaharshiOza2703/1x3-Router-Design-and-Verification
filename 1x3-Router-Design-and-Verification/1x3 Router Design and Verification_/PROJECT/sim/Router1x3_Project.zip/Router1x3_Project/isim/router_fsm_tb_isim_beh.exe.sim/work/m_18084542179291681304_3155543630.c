/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/maharshioza/Downloads/3436-verilog_labs_f/Verilog_labs/PROJECT/tb/router_fsm_tb.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {1U, 0U};
static int ng4[] = {1, 0};



static int sp_initialize(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2072);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(37, ng0);

LAB5:    xsi_set_current_line(38, ng0);
    t5 = ((char*)((ng1)));
    t6 = (t1 + 8144);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 1);
    t7 = (t1 + 7984);
    xsi_vlogvar_assign_value(t7, t5, 1, 0, 1);
    t8 = (t1 + 6864);
    xsi_vlogvar_assign_value(t8, t5, 2, 0, 1);
    t9 = (t1 + 7344);
    xsi_vlogvar_assign_value(t9, t5, 3, 0, 1);
    t10 = (t1 + 7184);
    xsi_vlogvar_assign_value(t10, t5, 4, 0, 1);
    t11 = (t1 + 7024);
    xsi_vlogvar_assign_value(t11, t5, 5, 0, 1);
    t12 = (t1 + 6704);
    xsi_vlogvar_assign_value(t12, t5, 6, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_rst(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2504);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(43, ng0);

LAB5:    xsi_set_current_line(44, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(45, ng0);
    t8 = ((char*)((ng2)));
    t9 = (t1 + 6544);
    xsi_vlogvar_assign_value(t9, t8, 0, 0, 1);
    xsi_set_current_line(46, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(47, ng0);
    t7 = ((char*)((ng3)));
    t8 = (t1 + 6544);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 1);
    goto LAB4;

}

static int sp_t1(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2936);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(52, ng0);

LAB5:    xsi_set_current_line(53, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(54, ng0);

LAB7:    xsi_set_current_line(55, ng0);
    t8 = ((char*)((ng4)));
    t9 = (t1 + 6704);
    xsi_vlogvar_wait_assign_value(t9, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(56, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 8304);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 2, 0LL);
    xsi_set_current_line(57, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t1 + 7024);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(59, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(60, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 32U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(61, ng0);

LAB10:    xsi_set_current_line(62, ng0);
    t10 = ((char*)((ng1)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    xsi_set_current_line(63, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 6704);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(65, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 48U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(66, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 64U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB12;
    goto LAB1;

LAB12:    xsi_set_current_line(67, ng0);
    t10 = ((char*)((ng1)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    goto LAB4;

}

static int sp_t2(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 3368);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(72, ng0);

LAB5:    xsi_set_current_line(73, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(74, ng0);

LAB7:    xsi_set_current_line(75, ng0);
    t8 = ((char*)((ng4)));
    t9 = (t1 + 6704);
    xsi_vlogvar_wait_assign_value(t9, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(76, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 8304);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 2, 0LL);
    xsi_set_current_line(77, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t1 + 7024);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(79, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(80, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 32U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(81, ng0);
    t10 = ((char*)((ng4)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    xsi_set_current_line(82, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 48U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB10;
    goto LAB1;

LAB10:    xsi_set_current_line(83, ng0);
    t7 = ((char*)((ng1)));
    t8 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(84, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 64U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(85, ng0);

LAB12:    xsi_set_current_line(86, ng0);
    t7 = ((char*)((ng1)));
    t8 = (t1 + 7984);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(87, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t1 + 8144);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(89, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 80U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(90, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 96U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(91, ng0);
    t10 = ((char*)((ng1)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    goto LAB4;

}

static int sp_t3(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 3800);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(96, ng0);

LAB5:    xsi_set_current_line(97, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(98, ng0);

LAB7:    xsi_set_current_line(99, ng0);
    t8 = ((char*)((ng4)));
    t9 = (t1 + 6704);
    xsi_vlogvar_wait_assign_value(t9, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(100, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 8304);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 2, 0LL);
    xsi_set_current_line(101, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t1 + 7024);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(103, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(104, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 32U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(105, ng0);
    t10 = ((char*)((ng4)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    xsi_set_current_line(106, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 48U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB10;
    goto LAB1;

LAB10:    xsi_set_current_line(107, ng0);
    t7 = ((char*)((ng1)));
    t8 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(108, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 64U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(109, ng0);

LAB12:    xsi_set_current_line(110, ng0);
    t7 = ((char*)((ng1)));
    t8 = (t1 + 8144);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(111, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 7984);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(114, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 80U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(115, ng0);

LAB14:    xsi_set_current_line(116, ng0);
    t7 = ((char*)((ng1)));
    t8 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(117, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 6704);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(119, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 96U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB15;
    goto LAB1;

LAB15:    xsi_set_current_line(120, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 112U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB16;
    goto LAB1;

LAB16:    xsi_set_current_line(121, ng0);
    t10 = ((char*)((ng1)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    goto LAB4;

}

static int sp_t4(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 4232);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(126, ng0);

LAB5:    xsi_set_current_line(127, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(128, ng0);

LAB7:    xsi_set_current_line(129, ng0);
    t8 = ((char*)((ng4)));
    t9 = (t1 + 6704);
    xsi_vlogvar_wait_assign_value(t9, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(130, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 8304);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 2, 0LL);
    xsi_set_current_line(131, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t1 + 7024);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(133, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(134, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 32U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(135, ng0);

LAB10:    xsi_set_current_line(136, ng0);
    t10 = ((char*)((ng1)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    xsi_set_current_line(137, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 6704);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(139, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 48U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(140, ng0);
    t7 = (t2 + 88U);
    t8 = *((char **)t7);
    t9 = (t8 + 64U);
    xsi_wp_set_status(t9, 1);
    *((char **)t3) = &&LAB12;
    goto LAB1;

LAB12:    xsi_set_current_line(141, ng0);
    t10 = ((char*)((ng4)));
    t11 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t11, t10, 0, 0, 1, 0LL);
    xsi_set_current_line(142, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 80U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(143, ng0);
    t7 = ((char*)((ng1)));
    t8 = (t1 + 6864);
    xsi_vlogvar_wait_assign_value(t8, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(144, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 96U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(145, ng0);
    t7 = ((char*)((ng4)));
    t8 = (t1 + 7984);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 1);
    goto LAB4;

}

static void Initial_30_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 9216U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(31, ng0);

LAB4:    xsi_set_current_line(32, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 6384);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(33, ng0);

LAB5:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 9024);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(33, ng0);
    t3 = (t0 + 6384);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t7) == 0)
        goto LAB7;

LAB9:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t4 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t4) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 6384);
    xsi_vlogvar_assign_value(t24, t4, 0, 0, 1);
    goto LAB5;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t4) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB13:    goto LAB1;

}

static void Initial_150_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    t1 = (t0 + 9464U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(151, ng0);

LAB4:    xsi_set_current_line(152, ng0);
    t2 = (t0 + 9272);
    t3 = (t0 + 2504);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 9368);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 2504);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 9368);
    t15 = *((char **)t14);
    t14 = (t0 + 2504);
    t16 = (t0 + 9272);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(153, ng0);
    t2 = (t0 + 9272);
    t3 = (t0 + 2072);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB13:    t5 = (t0 + 9368);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB15:    if (t13 != 0)
        goto LAB16;

LAB11:    t6 = (t0 + 2072);
    xsi_vlog_subprogram_popinvocation(t6);

LAB12:    t14 = (t0 + 9368);
    t15 = *((char **)t14);
    t14 = (t0 + 2072);
    t16 = (t0 + 9272);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(155, ng0);
    t2 = (t0 + 9272);
    t3 = (t0 + 2936);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB19:    t5 = (t0 + 9368);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB21:    if (t13 != 0)
        goto LAB22;

LAB17:    t6 = (t0 + 2936);
    xsi_vlog_subprogram_popinvocation(t6);

LAB18:    t14 = (t0 + 9368);
    t15 = *((char **)t14);
    t14 = (t0 + 2936);
    t16 = (t0 + 9272);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(156, ng0);
    t2 = (t0 + 9272);
    t3 = (t0 + 2504);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB25:    t5 = (t0 + 9368);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB27:    if (t13 != 0)
        goto LAB28;

LAB23:    t6 = (t0 + 2504);
    xsi_vlog_subprogram_popinvocation(t6);

LAB24:    t14 = (t0 + 9368);
    t15 = *((char **)t14);
    t14 = (t0 + 2504);
    t16 = (t0 + 9272);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 9272);
    xsi_process_wait(t2, 1000000LL);
    *((char **)t1) = &&LAB29;

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 9464U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

LAB14:;
LAB16:    t5 = (t0 + 9464U);
    *((char **)t5) = &&LAB13;
    goto LAB1;

LAB20:;
LAB22:    t5 = (t0 + 9464U);
    *((char **)t5) = &&LAB19;
    goto LAB1;

LAB26:;
LAB28:    t5 = (t0 + 9464U);
    *((char **)t5) = &&LAB25;
    goto LAB1;

LAB29:    xsi_set_current_line(168, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

}


extern void work_m_18084542179291681304_3155543630_init()
{
	static char *pe[] = {(void *)Initial_30_0,(void *)Initial_150_1};
	static char *se[] = {(void *)sp_initialize,(void *)sp_rst,(void *)sp_t1,(void *)sp_t2,(void *)sp_t3,(void *)sp_t4};
	xsi_register_didat("work_m_18084542179291681304_3155543630", "isim/router_fsm_tb_isim_beh.exe.sim/work/m_18084542179291681304_3155543630.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
