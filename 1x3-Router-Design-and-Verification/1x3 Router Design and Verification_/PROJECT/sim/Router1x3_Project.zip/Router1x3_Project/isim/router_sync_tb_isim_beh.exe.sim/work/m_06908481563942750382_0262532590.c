/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/maharshioza/Downloads/3436-verilog_labs_f/Verilog_labs/PROJECT/tb/router_sync_tb.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {1U, 0U};
static int ng4[] = {1, 0};
static unsigned int ng5[] = {2U, 0U};
static const char *ng6 = "router_sync_tb.vcd";



static int sp_initialize(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 984);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(23, ng0);

LAB5:    xsi_set_current_line(24, ng0);
    t5 = ((char*)((ng1)));
    t6 = (t1 + 6688);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 1);
    t7 = (t1 + 6528);
    xsi_vlogvar_assign_value(t7, t5, 1, 0, 1);
    t8 = (t1 + 6368);
    xsi_vlogvar_assign_value(t8, t5, 2, 0, 1);
    t9 = (t1 + 6208);
    xsi_vlogvar_assign_value(t9, t5, 3, 0, 2);
    t10 = (t1 + 6048);
    xsi_vlogvar_assign_value(t10, t5, 5, 0, 1);
    xsi_set_current_line(25, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 7168);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    t6 = (t1 + 7008);
    xsi_vlogvar_assign_value(t6, t4, 1, 0, 1);
    t7 = (t1 + 6848);
    xsi_vlogvar_assign_value(t7, t4, 2, 0, 1);
    t8 = (t1 + 7808);
    xsi_vlogvar_assign_value(t8, t4, 3, 0, 1);
    t9 = (t1 + 7648);
    xsi_vlogvar_assign_value(t9, t4, 4, 0, 1);
    t10 = (t1 + 7488);
    xsi_vlogvar_assign_value(t10, t4, 5, 0, 1);
    t11 = (t1 + 7328);
    xsi_vlogvar_assign_value(t11, t4, 6, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_reset_dut(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1416);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(31, ng0);

LAB5:    xsi_set_current_line(32, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(33, ng0);
    t8 = ((char*)((ng2)));
    t9 = (t1 + 5888);
    xsi_vlogvar_assign_value(t9, t8, 0, 0, 1);
    xsi_set_current_line(34, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(35, ng0);
    t7 = ((char*)((ng3)));
    t8 = (t1 + 5888);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 1);
    goto LAB4;

}

static int sp_readenb(char *t1, char *t2)
{
    char t5[8];
    int t0;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(40, ng0);

LAB5:    xsi_set_current_line(41, ng0);
    t6 = (t1 + 8288);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 8128);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t1 + 7968);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    xsi_vlogtype_concat(t5, 3, 3, 3U, t14, 1, t11, 1, t8, 1);
    t15 = (t1 + 7808);
    xsi_vlogvar_assign_value(t15, t5, 0, 0, 1);
    t16 = (t1 + 7648);
    xsi_vlogvar_assign_value(t16, t5, 1, 0, 1);
    t17 = (t1 + 7488);
    xsi_vlogvar_assign_value(t17, t5, 2, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_detect_ad(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2280);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(46, ng0);

LAB5:    xsi_set_current_line(47, ng0);
    t5 = (t1 + 8448);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 6208);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 2);
    xsi_set_current_line(48, ng0);
    t4 = (t1 + 8608);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 6048);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_fifo_ful(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2712);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(53, ng0);

LAB5:    xsi_set_current_line(54, ng0);
    t5 = (t1 + 8768);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 6368);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 1);
    xsi_set_current_line(55, ng0);
    t4 = (t1 + 8928);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 6528);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);
    xsi_set_current_line(56, ng0);
    t4 = (t1 + 9088);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 6688);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_empty_dut(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 3144);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(61, ng0);

LAB5:    xsi_set_current_line(62, ng0);
    t5 = (t1 + 9248);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 6848);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 1);
    xsi_set_current_line(63, ng0);
    t4 = (t1 + 9408);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 7008);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);
    xsi_set_current_line(64, ng0);
    t4 = (t1 + 9568);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 7168);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_write_reg(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 3576);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(70, ng0);

LAB5:    xsi_set_current_line(71, ng0);
    t5 = (t1 + 9728);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 7328);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static void Initial_16_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 10640U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(17, ng0);

LAB4:    xsi_set_current_line(18, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 5728);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(19, ng0);

LAB5:    xsi_set_current_line(19, ng0);
    t2 = (t0 + 10448);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(19, ng0);
    t3 = (t0 + 5728);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t7) == 0)
        goto LAB7;

LAB9:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t4 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t4) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 5728);
    xsi_vlogvar_assign_value(t24, t4, 0, 0, 1);
    goto LAB5;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t4) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB13:    goto LAB1;

}

static void Initial_75_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    t1 = (t0 + 10888U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(76, ng0);

LAB4:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 10696);
    t3 = (t0 + 984);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 10792);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 984);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 10792);
    t15 = *((char **)t14);
    t14 = (t0 + 984);
    t16 = (t0 + 10696);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(78, ng0);
    t2 = (t0 + 10696);
    t3 = (t0 + 1416);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB13:    t5 = (t0 + 10792);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB15:    if (t13 != 0)
        goto LAB16;

LAB11:    t6 = (t0 + 1416);
    xsi_vlog_subprogram_popinvocation(t6);

LAB12:    t14 = (t0 + 10792);
    t15 = *((char **)t14);
    t14 = (t0 + 1416);
    t16 = (t0 + 10696);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(79, ng0);
    t2 = (t0 + 11488);
    *((int *)t2) = 1;
    t3 = (t0 + 10920);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB17;

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 10888U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

LAB14:;
LAB16:    t5 = (t0 + 10888U);
    *((char **)t5) = &&LAB13;
    goto LAB1;

LAB17:    xsi_set_current_line(80, ng0);
    t4 = ((char*)((ng4)));
    t5 = ((char*)((ng4)));
    t6 = ((char*)((ng1)));
    t7 = (t0 + 10696);
    t8 = (t0 + 1848);
    t9 = xsi_create_subprogram_invocation(t7, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 7968);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 1);
    t11 = (t0 + 8128);
    xsi_vlogvar_assign_value(t11, t5, 0, 0, 1);
    t12 = (t0 + 8288);
    xsi_vlogvar_assign_value(t12, t6, 0, 0, 1);

LAB20:    t14 = (t0 + 10792);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t13 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB22:    if (t13 != 0)
        goto LAB23;

LAB18:    t15 = (t0 + 1848);
    xsi_vlog_subprogram_popinvocation(t15);

LAB19:    t22 = (t0 + 10792);
    t23 = *((char **)t22);
    t22 = (t0 + 1848);
    t24 = (t0 + 10696);
    t25 = 0;
    xsi_delete_subprogram_invocation(t22, t23, t0, t24, t25);
    xsi_set_current_line(81, ng0);
    t2 = ((char*)((ng5)));
    t3 = ((char*)((ng4)));
    t4 = (t0 + 10696);
    t5 = (t0 + 2280);
    t6 = xsi_create_subprogram_invocation(t4, 0, t0, t5, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t5, t6);
    t7 = (t0 + 8448);
    xsi_vlogvar_assign_value(t7, t2, 0, 0, 2);
    t8 = (t0 + 8608);
    xsi_vlogvar_assign_value(t8, t3, 0, 0, 1);

LAB26:    t9 = (t0 + 10792);
    t10 = *((char **)t9);
    t11 = (t10 + 80U);
    t12 = *((char **)t11);
    t14 = (t12 + 272U);
    t15 = *((char **)t14);
    t16 = (t15 + 0U);
    t17 = *((char **)t16);
    t13 = ((int  (*)(char *, char *))t17)(t0, t10);

LAB28:    if (t13 != 0)
        goto LAB29;

LAB24:    t10 = (t0 + 2280);
    xsi_vlog_subprogram_popinvocation(t10);

LAB25:    t18 = (t0 + 10792);
    t19 = *((char **)t18);
    t18 = (t0 + 2280);
    t20 = (t0 + 10696);
    t21 = 0;
    xsi_delete_subprogram_invocation(t18, t19, t0, t20, t21);
    xsi_set_current_line(82, ng0);
    t2 = ((char*)((ng1)));
    t3 = ((char*)((ng1)));
    t4 = ((char*)((ng1)));
    t5 = (t0 + 10696);
    t6 = (t0 + 2712);
    t7 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t7);
    t8 = (t0 + 8768);
    xsi_vlogvar_assign_value(t8, t2, 0, 0, 1);
    t9 = (t0 + 8928);
    xsi_vlogvar_assign_value(t9, t3, 0, 0, 1);
    t10 = (t0 + 9088);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 1);

LAB32:    t11 = (t0 + 10792);
    t12 = *((char **)t11);
    t14 = (t12 + 80U);
    t15 = *((char **)t14);
    t16 = (t15 + 272U);
    t17 = *((char **)t16);
    t18 = (t17 + 0U);
    t19 = *((char **)t18);
    t13 = ((int  (*)(char *, char *))t19)(t0, t12);

LAB34:    if (t13 != 0)
        goto LAB35;

LAB30:    t12 = (t0 + 2712);
    xsi_vlog_subprogram_popinvocation(t12);

LAB31:    t20 = (t0 + 10792);
    t21 = *((char **)t20);
    t20 = (t0 + 2712);
    t22 = (t0 + 10696);
    t23 = 0;
    xsi_delete_subprogram_invocation(t20, t21, t0, t22, t23);
    xsi_set_current_line(83, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 10696);
    t4 = (t0 + 3576);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);
    t6 = (t0 + 9728);
    xsi_vlogvar_assign_value(t6, t2, 0, 0, 1);

LAB38:    t7 = (t0 + 10792);
    t8 = *((char **)t7);
    t9 = (t8 + 80U);
    t10 = *((char **)t9);
    t11 = (t10 + 272U);
    t12 = *((char **)t11);
    t14 = (t12 + 0U);
    t15 = *((char **)t14);
    t13 = ((int  (*)(char *, char *))t15)(t0, t8);

LAB40:    if (t13 != 0)
        goto LAB41;

LAB36:    t8 = (t0 + 3576);
    xsi_vlog_subprogram_popinvocation(t8);

LAB37:    t16 = (t0 + 10792);
    t17 = *((char **)t16);
    t16 = (t0 + 3576);
    t18 = (t0 + 10696);
    t19 = 0;
    xsi_delete_subprogram_invocation(t16, t17, t0, t18, t19);
    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng1)));
    t3 = ((char*)((ng1)));
    t4 = ((char*)((ng1)));
    t5 = (t0 + 10696);
    t6 = (t0 + 3144);
    t7 = xsi_create_subprogram_invocation(t5, 0, t0, t6, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t6, t7);
    t8 = (t0 + 9248);
    xsi_vlogvar_assign_value(t8, t2, 0, 0, 1);
    t9 = (t0 + 9408);
    xsi_vlogvar_assign_value(t9, t3, 0, 0, 1);
    t10 = (t0 + 9568);
    xsi_vlogvar_assign_value(t10, t4, 0, 0, 1);

LAB44:    t11 = (t0 + 10792);
    t12 = *((char **)t11);
    t14 = (t12 + 80U);
    t15 = *((char **)t14);
    t16 = (t15 + 272U);
    t17 = *((char **)t16);
    t18 = (t17 + 0U);
    t19 = *((char **)t18);
    t13 = ((int  (*)(char *, char *))t19)(t0, t12);

LAB46:    if (t13 != 0)
        goto LAB47;

LAB42:    t12 = (t0 + 3144);
    xsi_vlog_subprogram_popinvocation(t12);

LAB43:    t20 = (t0 + 10792);
    t21 = *((char **)t20);
    t20 = (t0 + 3144);
    t22 = (t0 + 10696);
    t23 = 0;
    xsi_delete_subprogram_invocation(t20, t21, t0, t22, t23);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 10696);
    xsi_process_wait(t2, 1000000LL);
    *((char **)t1) = &&LAB48;
    goto LAB1;

LAB21:;
LAB23:    t14 = (t0 + 10888U);
    *((char **)t14) = &&LAB20;
    goto LAB1;

LAB27:;
LAB29:    t9 = (t0 + 10888U);
    *((char **)t9) = &&LAB26;
    goto LAB1;

LAB33:;
LAB35:    t11 = (t0 + 10888U);
    *((char **)t11) = &&LAB32;
    goto LAB1;

LAB39:;
LAB41:    t7 = (t0 + 10888U);
    *((char **)t7) = &&LAB38;
    goto LAB1;

LAB45:;
LAB47:    t11 = (t0 + 10888U);
    *((char **)t11) = &&LAB44;
    goto LAB1;

LAB48:    xsi_set_current_line(86, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

}

static void Initial_89_2(char *t0)
{

LAB0:    xsi_set_current_line(90, ng0);

LAB2:    xsi_set_current_line(91, ng0);
    xsi_vcd_dumpfile(ng6);
    xsi_set_current_line(92, ng0);
    xsi_vcd_dumpvars(t0);

LAB1:    return;
}


extern void work_m_06908481563942750382_0262532590_init()
{
	static char *pe[] = {(void *)Initial_16_0,(void *)Initial_75_1,(void *)Initial_89_2};
	static char *se[] = {(void *)sp_initialize,(void *)sp_reset_dut,(void *)sp_readenb,(void *)sp_detect_ad,(void *)sp_fifo_ful,(void *)sp_empty_dut,(void *)sp_write_reg};
	xsi_register_didat("work_m_06908481563942750382_0262532590", "isim/router_sync_tb_isim_beh.exe.sim/work/m_06908481563942750382_0262532590.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
