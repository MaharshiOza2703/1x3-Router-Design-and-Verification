/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/maharshioza/Downloads/3436-verilog_labs_f/Verilog_labs/PROJECT/tb/router_top_tb.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static int ng3[] = {0, 0};
static int ng4[] = {5, 0};
static unsigned int ng5[] = {2U, 0U};
static int ng6[] = {256, 0};
static int ng7[] = {1, 0};
static int ng8[] = {2, 0};
static int ng9[] = {14, 0};
static int ng10[] = {16, 0};
static const char *ng11 = "router_top_tb.vcd";



static int sp_reset(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(45, ng0);

LAB5:    xsi_set_current_line(46, ng0);
    t5 = (t2 + 88U);
    t6 = *((char **)t5);
    t7 = (t6 + 0U);
    xsi_wp_set_status(t7, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(47, ng0);
    t8 = ((char*)((ng1)));
    t9 = (t1 + 4888);
    xsi_vlogvar_assign_value(t9, t8, 0, 0, 1);
    xsi_set_current_line(48, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(49, ng0);
    t7 = ((char*)((ng2)));
    t8 = (t1 + 4888);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 1);
    goto LAB4;

}

static int sp_initialize(char *t1, char *t2)
{
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1280);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(54, ng0);

LAB5:    xsi_set_current_line(55, ng0);
    t5 = ((char*)((ng2)));
    t6 = (t1 + 4888);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 1);
    xsi_set_current_line(56, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    t6 = (t1 + 5368);
    xsi_vlogvar_assign_value(t6, t4, 1, 0, 1);
    t7 = (t1 + 5208);
    xsi_vlogvar_assign_value(t7, t4, 2, 0, 1);
    t8 = (t1 + 5048);
    xsi_vlogvar_assign_value(t8, t4, 3, 0, 1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
}

static int sp_pktm_gen_5(char *t1, char *t2)
{
    char t7[8];
    char t29[8];
    char t45[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    int t46;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1712);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(65, ng0);

LAB5:    xsi_set_current_line(66, ng0);
    t5 = ((char*)((ng3)));
    t6 = (t1 + 6328);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 8);
    xsi_set_current_line(67, ng0);

LAB6:    t4 = (t1 + 4328U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t4) == 0)
        goto LAB7;

LAB9:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;

LAB10:    t13 = (t7 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB12;

LAB11:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 0U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB7:    *((unsigned int *)t7) = 1;
    goto LAB10;

LAB12:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 0U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(68, ng0);

LAB13:    xsi_set_current_line(69, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 16U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(70, ng0);
    t4 = ((char*)((ng4)));
    t5 = (t1 + 6488);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 9);
    xsi_set_current_line(71, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 5528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(72, ng0);
    t4 = ((char*)((ng5)));
    t5 = (t1 + 6488);
    t6 = (t5 + 56U);
    t13 = *((char **)t6);
    xsi_vlogtype_concat(t7, 11, 11, 2U, t13, 9, t4, 2);
    t19 = (t1 + 6008);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 8);
    xsi_set_current_line(73, ng0);
    t4 = (t1 + 6008);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(74, ng0);
    t4 = (t1 + 6328);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t20);
    t10 = (t8 ^ t9);
    *((unsigned int *)t7) = t10;
    t21 = (t6 + 4);
    t22 = (t20 + 4);
    t23 = (t7 + 4);
    t11 = *((unsigned int *)t21);
    t12 = *((unsigned int *)t22);
    t14 = (t11 | t12);
    *((unsigned int *)t23) = t14;
    t15 = *((unsigned int *)t23);
    t16 = (t15 != 0);
    if (t16 == 1)
        goto LAB15;

LAB16:
LAB17:    t24 = (t1 + 6328);
    xsi_vlogvar_assign_value(t24, t7, 0, 0, 8);
    xsi_set_current_line(76, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB18;
    goto LAB1;

LAB15:    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t23);
    *((unsigned int *)t7) = (t17 | t18);
    goto LAB17;

LAB18:    xsi_set_current_line(78, ng0);
    xsi_set_current_line(78, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB19:    t4 = (t1 + 5848);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 6488);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    memset(t7, 0, 8);
    t21 = (t6 + 4);
    if (*((unsigned int *)t21) != 0)
        goto LAB21;

LAB20:    t22 = (t20 + 4);
    if (*((unsigned int *)t22) != 0)
        goto LAB21;

LAB24:    if (*((unsigned int *)t6) < *((unsigned int *)t20))
        goto LAB22;

LAB23:    t24 = (t7 + 4);
    t8 = *((unsigned int *)t24);
    t9 = (~(t8));
    t10 = *((unsigned int *)t7);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB25;

LAB26:    xsi_set_current_line(89, ng0);

LAB40:    t4 = (t1 + 4328U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB44;

LAB42:    if (*((unsigned int *)t4) == 0)
        goto LAB41;

LAB43:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;

LAB44:    t13 = (t7 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB46;

LAB45:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 80U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB40;
    goto LAB1;

LAB21:    t23 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB23;

LAB22:    *((unsigned int *)t7) = 1;
    goto LAB23;

LAB25:    xsi_set_current_line(79, ng0);

LAB27:    xsi_set_current_line(80, ng0);

LAB28:    t25 = (t1 + 4328U);
    t26 = *((char **)t25);
    memset(t29, 0, 8);
    t25 = (t26 + 4);
    t14 = *((unsigned int *)t25);
    t15 = (~(t14));
    t16 = *((unsigned int *)t26);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB32;

LAB30:    if (*((unsigned int *)t25) == 0)
        goto LAB29;

LAB31:    t27 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t27) = 1;

LAB32:    t28 = (t29 + 4);
    t30 = *((unsigned int *)t28);
    t31 = (~(t30));
    t32 = *((unsigned int *)t29);
    t33 = (t32 & t31);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB34;

LAB33:    t35 = (t2 + 88U);
    t36 = *((char **)t35);
    t37 = (t36 + 48U);
    xsi_wp_set_status(t37, 1);
    t38 = (t2 + 48U);
    *((char **)t38) = &&LAB28;
    goto LAB1;

LAB29:    *((unsigned int *)t29) = 1;
    goto LAB32;

LAB34:    t39 = (t2 + 88U);
    t40 = *((char **)t39);
    t41 = (t40 + 48U);
    xsi_wp_set_status(t41, 0);
    xsi_set_current_line(81, ng0);

LAB35:    xsi_set_current_line(82, ng0);
    t42 = (t2 + 88U);
    t43 = *((char **)t42);
    t44 = (t43 + 64U);
    xsi_wp_set_status(t44, 1);
    *((char **)t3) = &&LAB36;
    goto LAB1;

LAB36:    xsi_set_current_line(83, ng0);
    *((int *)t29) = xsi_vlog_rtl_dist_uniform(0, 0, -2147483648, 2147483647);
    t4 = (t29 + 4);
    *((int *)t4) = 0;
    xsi_vlogtype_concat(t7, 32, 32, 1U, t29, 32);
    t5 = ((char*)((ng6)));
    memset(t45, 0, 8);
    xsi_vlog_unsigned_mod(t45, 32, t7, 32, t5, 32);
    t6 = (t1 + 6168);
    xsi_vlogvar_assign_value(t6, t45, 0, 0, 8);
    xsi_set_current_line(84, ng0);
    t4 = (t1 + 6168);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(85, ng0);
    t4 = (t1 + 6328);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t20);
    t10 = (t8 ^ t9);
    *((unsigned int *)t7) = t10;
    t21 = (t6 + 4);
    t22 = (t20 + 4);
    t23 = (t7 + 4);
    t11 = *((unsigned int *)t21);
    t12 = *((unsigned int *)t22);
    t14 = (t11 | t12);
    *((unsigned int *)t23) = t14;
    t15 = *((unsigned int *)t23);
    t16 = (t15 != 0);
    if (t16 == 1)
        goto LAB37;

LAB38:
LAB39:    t24 = (t1 + 6328);
    xsi_vlogvar_assign_value(t24, t7, 0, 0, 8);
    xsi_set_current_line(78, ng0);
    t4 = (t1 + 5848);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = ((char*)((ng7)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t6, 32, t13, 32);
    t19 = (t1 + 5848);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 32);
    goto LAB19;

LAB37:    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t23);
    *((unsigned int *)t7) = (t17 | t18);
    goto LAB39;

LAB41:    *((unsigned int *)t7) = 1;
    goto LAB44;

LAB46:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 80U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(90, ng0);

LAB47:    xsi_set_current_line(91, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 96U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB48;
    goto LAB1;

LAB48:    xsi_set_current_line(92, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(93, ng0);
    t4 = (t1 + 6328);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(95, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t4 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (~(t8));
    t10 = *((unsigned int *)t4);
    t46 = (t10 & t9);
    t6 = (t1 + 12800);
    *((int *)t6) = t46;

LAB49:    t13 = (t1 + 12800);
    if (*((int *)t13) > 0)
        goto LAB50;

LAB51:    xsi_set_current_line(97, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 5368);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(99, ng0);

LAB53:    t4 = (t1 + 12832);
    t5 = *((char **)t4);
    t6 = ((((char*)(t5))) + 40U);
    t13 = *((char **)t6);
    t6 = (t13 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (~(t8));
    t10 = *((unsigned int *)t13);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB55;

LAB54:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 128U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB53;
    goto LAB1;

LAB50:    xsi_set_current_line(96, ng0);
    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 112U);
    xsi_wp_set_status(t21, 1);
    *((char **)t3) = &&LAB52;
    goto LAB1;

LAB52:    t4 = (t1 + 12800);
    t46 = *((int *)t4);
    *((int *)t4) = (t46 - 1);
    goto LAB49;

LAB55:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 128U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(100, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 144U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB56;
    goto LAB1;

LAB56:    xsi_set_current_line(101, ng0);
    t35 = ((char*)((ng3)));
    t36 = (t1 + 5368);
    xsi_vlogvar_assign_value(t36, t35, 0, 0, 1);
    goto LAB4;

}

static int sp_pktm_gen_14(char *t1, char *t2)
{
    char t7[8];
    char t29[8];
    char t45[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    int t46;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2144);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(110, ng0);

LAB5:    xsi_set_current_line(111, ng0);
    t5 = ((char*)((ng3)));
    t6 = (t1 + 6968);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 8);
    xsi_set_current_line(112, ng0);

LAB6:    t4 = (t1 + 4328U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t4) == 0)
        goto LAB7;

LAB9:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;

LAB10:    t13 = (t7 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB12;

LAB11:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 0U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB7:    *((unsigned int *)t7) = 1;
    goto LAB10;

LAB12:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 0U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(113, ng0);

LAB13:    xsi_set_current_line(114, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 16U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(115, ng0);
    t4 = ((char*)((ng9)));
    t5 = (t1 + 7128);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 9);
    xsi_set_current_line(116, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 5528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(117, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 7128);
    t6 = (t5 + 56U);
    t13 = *((char **)t6);
    xsi_vlogtype_concat(t7, 11, 11, 2U, t13, 9, t4, 2);
    t19 = (t1 + 6648);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 8);
    xsi_set_current_line(118, ng0);
    t4 = (t1 + 6648);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(119, ng0);
    t4 = (t1 + 6968);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t20);
    t10 = (t8 ^ t9);
    *((unsigned int *)t7) = t10;
    t21 = (t6 + 4);
    t22 = (t20 + 4);
    t23 = (t7 + 4);
    t11 = *((unsigned int *)t21);
    t12 = *((unsigned int *)t22);
    t14 = (t11 | t12);
    *((unsigned int *)t23) = t14;
    t15 = *((unsigned int *)t23);
    t16 = (t15 != 0);
    if (t16 == 1)
        goto LAB15;

LAB16:
LAB17:    t24 = (t1 + 6968);
    xsi_vlogvar_assign_value(t24, t7, 0, 0, 8);
    xsi_set_current_line(121, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB18;
    goto LAB1;

LAB15:    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t23);
    *((unsigned int *)t7) = (t17 | t18);
    goto LAB17;

LAB18:    xsi_set_current_line(123, ng0);
    xsi_set_current_line(123, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB19:    t4 = (t1 + 5848);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 7128);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    memset(t7, 0, 8);
    t21 = (t6 + 4);
    if (*((unsigned int *)t21) != 0)
        goto LAB21;

LAB20:    t22 = (t20 + 4);
    if (*((unsigned int *)t22) != 0)
        goto LAB21;

LAB24:    if (*((unsigned int *)t6) < *((unsigned int *)t20))
        goto LAB22;

LAB23:    t24 = (t7 + 4);
    t8 = *((unsigned int *)t24);
    t9 = (~(t8));
    t10 = *((unsigned int *)t7);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB25;

LAB26:    xsi_set_current_line(134, ng0);

LAB40:    t4 = (t1 + 4328U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB44;

LAB42:    if (*((unsigned int *)t4) == 0)
        goto LAB41;

LAB43:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;

LAB44:    t13 = (t7 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB46;

LAB45:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 80U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB40;
    goto LAB1;

LAB21:    t23 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB23;

LAB22:    *((unsigned int *)t7) = 1;
    goto LAB23;

LAB25:    xsi_set_current_line(124, ng0);

LAB27:    xsi_set_current_line(125, ng0);

LAB28:    t25 = (t1 + 4328U);
    t26 = *((char **)t25);
    memset(t29, 0, 8);
    t25 = (t26 + 4);
    t14 = *((unsigned int *)t25);
    t15 = (~(t14));
    t16 = *((unsigned int *)t26);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB32;

LAB30:    if (*((unsigned int *)t25) == 0)
        goto LAB29;

LAB31:    t27 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t27) = 1;

LAB32:    t28 = (t29 + 4);
    t30 = *((unsigned int *)t28);
    t31 = (~(t30));
    t32 = *((unsigned int *)t29);
    t33 = (t32 & t31);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB34;

LAB33:    t35 = (t2 + 88U);
    t36 = *((char **)t35);
    t37 = (t36 + 48U);
    xsi_wp_set_status(t37, 1);
    t38 = (t2 + 48U);
    *((char **)t38) = &&LAB28;
    goto LAB1;

LAB29:    *((unsigned int *)t29) = 1;
    goto LAB32;

LAB34:    t39 = (t2 + 88U);
    t40 = *((char **)t39);
    t41 = (t40 + 48U);
    xsi_wp_set_status(t41, 0);
    xsi_set_current_line(126, ng0);

LAB35:    xsi_set_current_line(127, ng0);
    t42 = (t2 + 88U);
    t43 = *((char **)t42);
    t44 = (t43 + 64U);
    xsi_wp_set_status(t44, 1);
    *((char **)t3) = &&LAB36;
    goto LAB1;

LAB36:    xsi_set_current_line(128, ng0);
    *((int *)t29) = xsi_vlog_rtl_dist_uniform(0, 0, -2147483648, 2147483647);
    t4 = (t29 + 4);
    *((int *)t4) = 0;
    xsi_vlogtype_concat(t7, 32, 32, 1U, t29, 32);
    t5 = ((char*)((ng6)));
    memset(t45, 0, 8);
    xsi_vlog_unsigned_mod(t45, 32, t7, 32, t5, 32);
    t6 = (t1 + 6808);
    xsi_vlogvar_assign_value(t6, t45, 0, 0, 8);
    xsi_set_current_line(129, ng0);
    t4 = (t1 + 6808);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(130, ng0);
    t4 = (t1 + 6968);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t20);
    t10 = (t8 ^ t9);
    *((unsigned int *)t7) = t10;
    t21 = (t6 + 4);
    t22 = (t20 + 4);
    t23 = (t7 + 4);
    t11 = *((unsigned int *)t21);
    t12 = *((unsigned int *)t22);
    t14 = (t11 | t12);
    *((unsigned int *)t23) = t14;
    t15 = *((unsigned int *)t23);
    t16 = (t15 != 0);
    if (t16 == 1)
        goto LAB37;

LAB38:
LAB39:    t24 = (t1 + 6968);
    xsi_vlogvar_assign_value(t24, t7, 0, 0, 8);
    xsi_set_current_line(123, ng0);
    t4 = (t1 + 5848);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = ((char*)((ng7)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t6, 32, t13, 32);
    t19 = (t1 + 5848);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 32);
    goto LAB19;

LAB37:    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t23);
    *((unsigned int *)t7) = (t17 | t18);
    goto LAB39;

LAB41:    *((unsigned int *)t7) = 1;
    goto LAB44;

LAB46:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 80U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(135, ng0);

LAB47:    xsi_set_current_line(136, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 96U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB48;
    goto LAB1;

LAB48:    xsi_set_current_line(137, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(138, ng0);
    t4 = (t1 + 6968);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(140, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t4 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (~(t8));
    t10 = *((unsigned int *)t4);
    t46 = (t10 & t9);
    t6 = (t1 + 12840);
    *((int *)t6) = t46;

LAB49:    t13 = (t1 + 12840);
    if (*((int *)t13) > 0)
        goto LAB50;

LAB51:    xsi_set_current_line(142, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 5208);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(144, ng0);

LAB53:    t4 = (t1 + 12872);
    t5 = *((char **)t4);
    t6 = ((((char*)(t5))) + 40U);
    t13 = *((char **)t6);
    t6 = (t13 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (~(t8));
    t10 = *((unsigned int *)t13);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB55;

LAB54:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 128U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB53;
    goto LAB1;

LAB50:    xsi_set_current_line(141, ng0);
    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 112U);
    xsi_wp_set_status(t21, 1);
    *((char **)t3) = &&LAB52;
    goto LAB1;

LAB52:    t4 = (t1 + 12840);
    t46 = *((int *)t4);
    *((int *)t4) = (t46 - 1);
    goto LAB49;

LAB55:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 128U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(145, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 144U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB56;
    goto LAB1;

LAB56:    xsi_set_current_line(146, ng0);
    t35 = ((char*)((ng3)));
    t36 = (t1 + 5208);
    xsi_vlogvar_assign_value(t36, t35, 0, 0, 1);
    goto LAB4;

}

static int sp_pktm_gen_16(char *t1, char *t2)
{
    char t7[8];
    char t29[8];
    char t45[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    int t46;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2576);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(154, ng0);

LAB5:    xsi_set_current_line(155, ng0);
    t5 = ((char*)((ng3)));
    t6 = (t1 + 7608);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 8);
    xsi_set_current_line(156, ng0);

LAB6:    t4 = (t1 + 4328U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t4) == 0)
        goto LAB7;

LAB9:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;

LAB10:    t13 = (t7 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB12;

LAB11:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 0U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB7:    *((unsigned int *)t7) = 1;
    goto LAB10;

LAB12:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 0U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(157, ng0);

LAB13:    xsi_set_current_line(158, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 16U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(159, ng0);
    t4 = ((char*)((ng10)));
    t5 = (t1 + 7768);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 9);
    xsi_set_current_line(160, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 5528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(161, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 7768);
    t6 = (t5 + 56U);
    t13 = *((char **)t6);
    xsi_vlogtype_concat(t7, 11, 11, 2U, t13, 9, t4, 2);
    t19 = (t1 + 7288);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 8);
    xsi_set_current_line(162, ng0);
    t4 = (t1 + 7288);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(163, ng0);
    t4 = (t1 + 7608);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t20);
    t10 = (t8 ^ t9);
    *((unsigned int *)t7) = t10;
    t21 = (t6 + 4);
    t22 = (t20 + 4);
    t23 = (t7 + 4);
    t11 = *((unsigned int *)t21);
    t12 = *((unsigned int *)t22);
    t14 = (t11 | t12);
    *((unsigned int *)t23) = t14;
    t15 = *((unsigned int *)t23);
    t16 = (t15 != 0);
    if (t16 == 1)
        goto LAB15;

LAB16:
LAB17:    t24 = (t1 + 7608);
    xsi_vlogvar_assign_value(t24, t7, 0, 0, 8);
    xsi_set_current_line(165, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB18;
    goto LAB1;

LAB15:    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t23);
    *((unsigned int *)t7) = (t17 | t18);
    goto LAB17;

LAB18:    xsi_set_current_line(167, ng0);
    xsi_set_current_line(167, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB19:    t4 = (t1 + 5848);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 7768);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    memset(t7, 0, 8);
    t21 = (t6 + 4);
    if (*((unsigned int *)t21) != 0)
        goto LAB21;

LAB20:    t22 = (t20 + 4);
    if (*((unsigned int *)t22) != 0)
        goto LAB21;

LAB24:    if (*((unsigned int *)t6) < *((unsigned int *)t20))
        goto LAB22;

LAB23:    t24 = (t7 + 4);
    t8 = *((unsigned int *)t24);
    t9 = (~(t8));
    t10 = *((unsigned int *)t7);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB25;

LAB26:    xsi_set_current_line(178, ng0);

LAB40:    t4 = (t1 + 4328U);
    t5 = *((char **)t4);
    memset(t7, 0, 8);
    t4 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t5);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB44;

LAB42:    if (*((unsigned int *)t4) == 0)
        goto LAB41;

LAB43:    t6 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;

LAB44:    t13 = (t7 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB46;

LAB45:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 80U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB40;
    goto LAB1;

LAB21:    t23 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB23;

LAB22:    *((unsigned int *)t7) = 1;
    goto LAB23;

LAB25:    xsi_set_current_line(168, ng0);

LAB27:    xsi_set_current_line(169, ng0);

LAB28:    t25 = (t1 + 4328U);
    t26 = *((char **)t25);
    memset(t29, 0, 8);
    t25 = (t26 + 4);
    t14 = *((unsigned int *)t25);
    t15 = (~(t14));
    t16 = *((unsigned int *)t26);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB32;

LAB30:    if (*((unsigned int *)t25) == 0)
        goto LAB29;

LAB31:    t27 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t27) = 1;

LAB32:    t28 = (t29 + 4);
    t30 = *((unsigned int *)t28);
    t31 = (~(t30));
    t32 = *((unsigned int *)t29);
    t33 = (t32 & t31);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB34;

LAB33:    t35 = (t2 + 88U);
    t36 = *((char **)t35);
    t37 = (t36 + 48U);
    xsi_wp_set_status(t37, 1);
    t38 = (t2 + 48U);
    *((char **)t38) = &&LAB28;
    goto LAB1;

LAB29:    *((unsigned int *)t29) = 1;
    goto LAB32;

LAB34:    t39 = (t2 + 88U);
    t40 = *((char **)t39);
    t41 = (t40 + 48U);
    xsi_wp_set_status(t41, 0);
    xsi_set_current_line(170, ng0);

LAB35:    xsi_set_current_line(171, ng0);
    t42 = (t2 + 88U);
    t43 = *((char **)t42);
    t44 = (t43 + 64U);
    xsi_wp_set_status(t44, 1);
    *((char **)t3) = &&LAB36;
    goto LAB1;

LAB36:    xsi_set_current_line(172, ng0);
    *((int *)t29) = xsi_vlog_rtl_dist_uniform(0, 0, -2147483648, 2147483647);
    t4 = (t29 + 4);
    *((int *)t4) = 0;
    xsi_vlogtype_concat(t7, 32, 32, 1U, t29, 32);
    t5 = ((char*)((ng6)));
    memset(t45, 0, 8);
    xsi_vlog_unsigned_mod(t45, 32, t7, 32, t5, 32);
    t6 = (t1 + 7448);
    xsi_vlogvar_assign_value(t6, t45, 0, 0, 8);
    xsi_set_current_line(173, ng0);
    t4 = (t1 + 7448);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(174, ng0);
    t4 = (t1 + 7608);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    t19 = (t13 + 56U);
    t20 = *((char **)t19);
    t8 = *((unsigned int *)t6);
    t9 = *((unsigned int *)t20);
    t10 = (t8 ^ t9);
    *((unsigned int *)t7) = t10;
    t21 = (t6 + 4);
    t22 = (t20 + 4);
    t23 = (t7 + 4);
    t11 = *((unsigned int *)t21);
    t12 = *((unsigned int *)t22);
    t14 = (t11 | t12);
    *((unsigned int *)t23) = t14;
    t15 = *((unsigned int *)t23);
    t16 = (t15 != 0);
    if (t16 == 1)
        goto LAB37;

LAB38:
LAB39:    t24 = (t1 + 7608);
    xsi_vlogvar_assign_value(t24, t7, 0, 0, 8);
    xsi_set_current_line(167, ng0);
    t4 = (t1 + 5848);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = ((char*)((ng7)));
    memset(t7, 0, 8);
    xsi_vlog_signed_add(t7, 32, t6, 32, t13, 32);
    t19 = (t1 + 5848);
    xsi_vlogvar_assign_value(t19, t7, 0, 0, 32);
    goto LAB19;

LAB37:    t17 = *((unsigned int *)t7);
    t18 = *((unsigned int *)t23);
    *((unsigned int *)t7) = (t17 | t18);
    goto LAB39;

LAB41:    *((unsigned int *)t7) = 1;
    goto LAB44;

LAB46:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 80U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(179, ng0);

LAB47:    xsi_set_current_line(180, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 96U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB48;
    goto LAB1;

LAB48:    xsi_set_current_line(181, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 5528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(182, ng0);
    t4 = (t1 + 7608);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t13 = (t1 + 5688);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 8);
    xsi_set_current_line(184, ng0);
    t4 = ((char*)((ng8)));
    t5 = (t4 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (~(t8));
    t10 = *((unsigned int *)t4);
    t46 = (t10 & t9);
    t6 = (t1 + 12880);
    *((int *)t6) = t46;

LAB49:    t13 = (t1 + 12880);
    if (*((int *)t13) > 0)
        goto LAB50;

LAB51:    xsi_set_current_line(186, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 5048);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(188, ng0);

LAB53:    t4 = (t1 + 12912);
    t5 = *((char **)t4);
    t6 = ((((char*)(t5))) + 40U);
    t13 = *((char **)t6);
    t6 = (t13 + 4);
    t8 = *((unsigned int *)t6);
    t9 = (~(t8));
    t10 = *((unsigned int *)t13);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB55;

LAB54:    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 128U);
    xsi_wp_set_status(t21, 1);
    t22 = (t2 + 48U);
    *((char **)t22) = &&LAB53;
    goto LAB1;

LAB50:    xsi_set_current_line(185, ng0);
    t19 = (t2 + 88U);
    t20 = *((char **)t19);
    t21 = (t20 + 112U);
    xsi_wp_set_status(t21, 1);
    *((char **)t3) = &&LAB52;
    goto LAB1;

LAB52:    t4 = (t1 + 12880);
    t46 = *((int *)t4);
    *((int *)t4) = (t46 - 1);
    goto LAB49;

LAB55:    t23 = (t2 + 88U);
    t24 = *((char **)t23);
    t25 = (t24 + 128U);
    xsi_wp_set_status(t25, 0);
    xsi_set_current_line(189, ng0);
    t26 = (t2 + 88U);
    t27 = *((char **)t26);
    t28 = (t27 + 144U);
    xsi_wp_set_status(t28, 1);
    *((char **)t3) = &&LAB56;
    goto LAB1;

LAB56:    xsi_set_current_line(190, ng0);
    t35 = ((char*)((ng3)));
    t36 = (t1 + 5048);
    xsi_vlogvar_assign_value(t36, t35, 0, 0, 1);
    goto LAB4;

}

static void Initial_36_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 8680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(37, ng0);

LAB4:    xsi_set_current_line(38, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 4728);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(39, ng0);

LAB5:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 8488);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(40, ng0);
    t3 = (t0 + 4728);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB10;

LAB8:    if (*((unsigned int *)t7) == 0)
        goto LAB7;

LAB9:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;

LAB10:    t14 = (t4 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t4) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB12;

LAB11:    t22 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 4728);
    xsi_vlogvar_assign_value(t24, t4, 0, 0, 1);
    goto LAB5;

LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB12:    t18 = *((unsigned int *)t4);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t4) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB11;

LAB13:    goto LAB1;

}

static void Initial_196_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    t1 = (t0 + 8928U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(197, ng0);

LAB4:    xsi_set_current_line(198, ng0);
    t2 = (t0 + 8736);
    t3 = (t0 + 1280);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 8832);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 1280);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 8832);
    t15 = *((char **)t14);
    t14 = (t0 + 1280);
    t16 = (t0 + 8736);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(199, ng0);
    t2 = (t0 + 8736);
    t3 = (t0 + 848);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB13:    t5 = (t0 + 8832);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB15:    if (t13 != 0)
        goto LAB16;

LAB11:    t6 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t6);

LAB12:    t14 = (t0 + 8832);
    t15 = *((char **)t14);
    t14 = (t0 + 848);
    t16 = (t0 + 8736);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(200, ng0);
    t2 = (t0 + 8736);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB17;

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 8928U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

LAB14:;
LAB16:    t5 = (t0 + 8928U);
    *((char **)t5) = &&LAB13;
    goto LAB1;

LAB17:    xsi_set_current_line(201, ng0);
    t2 = (t0 + 8736);
    t3 = (t0 + 1712);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB20:    t5 = (t0 + 8832);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB22:    if (t13 != 0)
        goto LAB23;

LAB18:    t6 = (t0 + 1712);
    xsi_vlog_subprogram_popinvocation(t6);

LAB19:    t14 = (t0 + 8832);
    t15 = *((char **)t14);
    t14 = (t0 + 1712);
    t16 = (t0 + 8736);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(202, ng0);
    t2 = (t0 + 8736);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB24;
    goto LAB1;

LAB21:;
LAB23:    t5 = (t0 + 8928U);
    *((char **)t5) = &&LAB20;
    goto LAB1;

LAB24:    xsi_set_current_line(204, ng0);
    t2 = (t0 + 8736);
    t3 = (t0 + 2144);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB27:    t5 = (t0 + 8832);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB29:    if (t13 != 0)
        goto LAB30;

LAB25:    t6 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t6);

LAB26:    t14 = (t0 + 8832);
    t15 = *((char **)t14);
    t14 = (t0 + 2144);
    t16 = (t0 + 8736);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(205, ng0);
    t2 = (t0 + 8736);
    xsi_process_wait(t2, 100000LL);
    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB28:;
LAB30:    t5 = (t0 + 8928U);
    *((char **)t5) = &&LAB27;
    goto LAB1;

LAB31:    xsi_set_current_line(206, ng0);
    t2 = (t0 + 8736);
    t3 = (t0 + 2576);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB34:    t5 = (t0 + 8832);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB36:    if (t13 != 0)
        goto LAB37;

LAB32:    t6 = (t0 + 2576);
    xsi_vlog_subprogram_popinvocation(t6);

LAB33:    t14 = (t0 + 8832);
    t15 = *((char **)t14);
    t14 = (t0 + 2576);
    t16 = (t0 + 8736);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);
    xsi_set_current_line(207, ng0);
    t2 = (t0 + 8736);
    xsi_process_wait(t2, 700000LL);
    *((char **)t1) = &&LAB38;
    goto LAB1;

LAB35:;
LAB37:    t5 = (t0 + 8928U);
    *((char **)t5) = &&LAB34;
    goto LAB1;

LAB38:    xsi_set_current_line(208, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

}

static void Initial_211_2(char *t0)
{

LAB0:    xsi_set_current_line(212, ng0);

LAB2:    xsi_set_current_line(213, ng0);
    xsi_vcd_dumpfile(ng11);
    xsi_set_current_line(214, ng0);
    xsi_vcd_dumpvars(t0);

LAB1:    return;
}


extern void work_m_17904203890278769705_4117270559_init()
{
	static char *pe[] = {(void *)Initial_36_0,(void *)Initial_196_1,(void *)Initial_211_2};
	static char *se[] = {(void *)sp_reset,(void *)sp_initialize,(void *)sp_pktm_gen_5,(void *)sp_pktm_gen_14,(void *)sp_pktm_gen_16};
	xsi_register_didat("work_m_17904203890278769705_4117270559", "isim/router_top_tb_isim_beh.exe.sim/work/m_17904203890278769705_4117270559.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
